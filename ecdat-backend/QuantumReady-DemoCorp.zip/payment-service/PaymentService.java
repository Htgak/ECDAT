import javax.crypto.*; import java.security.*; class Demo { void run() throws Exception { Signature.getInstance("SHA256withRSA"); } }
